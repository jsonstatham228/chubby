"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SwapMode = void 0;
var SwapMode;
(function (SwapMode) {
    SwapMode["ExactInOrOut"] = "ExactInOrOut";
    SwapMode["ExactIn"] = "ExactIn";
    SwapMode["ExactOut"] = "ExactOut";
})(SwapMode || (exports.SwapMode = SwapMode = {}));
